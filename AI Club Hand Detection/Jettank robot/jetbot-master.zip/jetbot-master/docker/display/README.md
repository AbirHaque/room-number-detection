# Display Container

This container includes

* A launch script to show JetBot stats on PiOLED display

#### Build

```bash
cd docker/display
./build.sh
```

#### Run

```bash
cd docker/display
./enable.sh
```

