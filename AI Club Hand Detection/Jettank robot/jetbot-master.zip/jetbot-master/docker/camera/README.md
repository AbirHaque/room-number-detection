# Camera Container

This container includes

* A launch script to publish camera images using ZMQ for access in other containers

#### Build

```bash
cd docker/camera
./build.sh
```

#### Run

```bash
cd docker/camera
./enable.sh
```

